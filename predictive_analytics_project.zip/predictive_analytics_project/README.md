# Predictive Analytics Using Historical Data

Build, validate and use a model that forecasts future trends from historical data.
The project covers the whole workflow: **clean -> explore -> model -> validate -> forecast**.

## Quick start

```bash
pip install -r requirements.txt
python run_pipeline.py                 # runs everything in ~10 seconds
python -m unittest discover -s tests   # optional: run the tests
```

Open **`REPORT.md`** for the results, or browse `outputs/figures/`.

### Use your own data

```bash
python run_pipeline.py --data my_data.csv --date-col Date --target-col Revenue --freq MS --horizon 12
```

| Option | Meaning | Default |
|---|---|---|
| `--freq` | `MS` monthly, `QS` quarterly, `D` daily | `MS` |
| `--season-length` | length of the seasonal cycle | 12 / 4 / 7 by freq |
| `--horizon` | periods to forecast (also the hold-out size) | 12 |
| `--cv-folds` | walk-forward validation folds | 5 |

The CSV needs one date column and one numeric column, one row per period.

## Project structure

```
run_pipeline.py        main script (the whole workflow)
REPORT.md              auto-generated results report
requirements.txt
src/
  data_generator.py    synthetic messy sales history (monthly, 2014-2025)
  preprocessing.py     parsing, de-duplication, gap filling, outlier handling, decomposition
  features.py          lag / rolling / calendar features
  models.py            Seasonal Naive, Holt-Winters, Linear, Ridge, Random Forest, Gradient Boosting
  evaluation.py        MAE / RMSE / MAPE / R2, walk-forward CV, hold-out test, prediction intervals
  visualization.py     all plots
tests/test_pipeline.py unit tests
data/raw/              input CSV          data/processed/  cleaned series
outputs/               metrics CSVs, forecast CSV, cleaning report, figures/
```

## How it works

**1. Cleaning & preprocessing** (`preprocessing.py`)
Dates are parsed, text in numeric columns becomes missing, duplicates are removed, rows are sorted,
and absent periods are inserted so the series has a regular index. Missing values are filled by time
interpolation. Outliers are found with a robust z-score (median/MAD) on the *decomposition residual*,
so normal seasonal peaks are not mistaken for errors. Only **isolated** spikes are replaced; a run of
consecutive unusual points is treated as a real level shift and kept.

**2. Trend analysis** — decomposition into trend / seasonality / residual, a seasonal box plot and an autocorrelation plot.

**3. Models**

| Model | Type | Idea |
|---|---|---|
| Seasonal Naive | baseline | "same as last year" - any real model must beat this |
| Holt-Winters | time-series | exponential smoothing with damped trend + seasonality (own SciPy implementation, run on log scale) |
| Linear / Ridge Regression | regression | predict from lags, rolling means, momentum, seasonal position |
| Random Forest / Gradient Boosting | regression (ML) | same features, non-linear |

The regression models work on a **log-transformed, linearly detrended** target (tree models cannot
extrapolate a trend) and forecast **recursively**: each prediction becomes the next lag. All features
use only past values, so there is no data leakage.

**4. Validation**
* *Walk-forward cross-validation* (expanding window, 5 x 12-month forecasts) selects the model.
  Random shuffled K-fold is deliberately avoided: it would train on the future.
* A final *hold-out* block (last 12 periods) is touched only once, for an unbiased score.
* Metrics: MAE, RMSE, MAPE, R2.

**5. Forecast** — the best model is refitted on all data and forecasts the next 12 periods with
80% intervals taken from the empirical backtest errors.

## Output files

| File | Content |
|---|---|
| `outputs/model_comparison.csv` | CV and hold-out metrics for every model |
| `outputs/forecast_next_periods.csv` | forecast with lower / upper 80% bounds |
| `outputs/cleaning_report.json` | what was fixed in the data |
| `outputs/cv_predictions.csv` | every backtest prediction |
| `outputs/figures/*.png` | 9 figures (cleaning, decomposition, seasonality, ACF, model comparison, test predictions, residuals, feature importance, forecast) |

## Ideas to extend

Add external drivers (price, promotions, holidays, weather), try SARIMA / Prophet / LSTM, tune
hyper-parameters with the walk-forward CV, add direct multi-step models, or build a Streamlit dashboard.
