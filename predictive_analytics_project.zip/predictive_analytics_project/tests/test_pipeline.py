"""Run with:  python -m unittest discover -s tests -v"""
import unittest

import numpy as np
import pandas as pd

from src.data_generator import generate_sales_data
from src.evaluation import regression_metrics, rolling_origin_cv
from src.models import HoltWinters, SeasonalNaive, build_model_factories
from src.preprocessing import clean_series


def _clean():
    df = generate_sales_data()
    return clean_series(df, "date", "monthly_sales", "MS", 12)


class TestPreprocessing(unittest.TestCase):
    def test_clean_series_is_regular_and_complete(self):
        y, report, *_ = _clean()
        self.assertEqual(len(y), 144)
        self.assertFalse(y.isna().any())
        self.assertTrue(y.index.is_monotonic_increasing)
        self.assertEqual(pd.infer_freq(y.index), "MS")
        self.assertEqual(report["duplicate_rows_removed"], 3)
        self.assertGreaterEqual(report["outliers_replaced"], 1)


class TestMetrics(unittest.TestCase):
    def test_known_values(self):
        m = regression_metrics([100, 200], [110, 180])
        self.assertAlmostEqual(m["MAE"], 15.0)
        self.assertAlmostEqual(m["RMSE"], np.sqrt((100 + 400) / 2))
        self.assertAlmostEqual(m["MAPE_%"], 10.0)


class TestModels(unittest.TestCase):
    def setUp(self):
        self.y, *_ = _clean()

    def test_seasonal_naive_repeats_last_cycle(self):
        f = SeasonalNaive(12).fit(self.y).forecast(12)
        np.testing.assert_allclose(f, self.y.to_numpy()[-12:])

    def test_holt_winters_forecast_shape_and_sign(self):
        f = HoltWinters(12).fit(self.y).forecast(12)
        self.assertEqual(len(f), 12)
        self.assertTrue(np.all(np.isfinite(f)) and np.all(f > 0))

    def test_all_models_forecast_future_dates(self):
        for name, make in build_model_factories(12).items():
            model = make().fit(self.y)
            self.assertEqual(len(model.forecast(6)), 6, name)
            self.assertEqual(model.future_index(6)[0], self.y.index[-1] + pd.offsets.MonthBegin(1))

    def test_cv_has_no_leakage_between_train_and_test(self):
        factories = {"Seasonal Naive": build_model_factories(12)["Seasonal Naive"]}
        _, preds = rolling_origin_cv(factories, self.y, horizon=12, n_folds=3)
        first_test_date = preds.groupby("fold")["date"].min()
        self.assertTrue(first_test_date.is_monotonic_increasing)
        self.assertEqual(len(preds), 36)


if __name__ == "__main__":
    unittest.main()
