# Predictive Analytics Report

**Target:** `monthly_sales`  |  **Frequency:** MS  |  **Seasonal period:** 12  |  **Forecast horizon:** 12

## 1. Data cleaning
Period covered: **2014-01-01 to 2025-12-01** (144 periods after cleaning, from 144 raw rows).

| Issue | Count | Treatment |
|---|---|---|
| Unparseable dates | 0 | dropped |
| Non-numeric values | 1 | converted to missing |
| Duplicate periods | 3 | removed |
| Missing periods (rows absent) | 3 | inserted as gaps |
| Missing values (total) | 10 | time interpolation |
| Isolated outliers | 4 | replaced by interpolation (2018-04-01, 2020-08-01, 2023-12-01, 2024-10-01) |

![cleaning](outputs/figures/01_data_cleaning.png)

## 2. Trend analysis
The decomposition separates a long-term trend from a repeating seasonal cycle and noise.

![decomposition](outputs/figures/02_decomposition.png)
![seasonality](outputs/figures/03_seasonality.png)

## 3. Models and validation
Six models were compared with **walk-forward cross-validation** (5 folds x 12-period forecasts) on the
training data, then scored once on the final 12 periods that no model had seen.

| model | CV_MAE | CV_RMSE | CV_MAPE_% | CV_R2 | CV_RMSE_std | Test_MAE | Test_RMSE | Test_MAPE_% | Test_R2 |
|---|---|---|---|---|---|---|---|---|---|
| Random Forest | 12.045 | 14.649 | 3.028 | 0.897 | 5.250 | 30.158 | 36.108 | 5.703 | 0.794 |
| Ridge Regression | 13.649 | 16.110 | 3.370 | 0.877 | 6.315 | 32.313 | 39.598 | 6.141 | 0.752 |
| Linear Regression | 13.655 | 16.210 | 3.365 | 0.875 | 6.442 | 32.427 | 39.653 | 6.165 | 0.751 |
| Gradient Boosting | 13.435 | 16.289 | 3.418 | 0.871 | 5.306 | 31.857 | 38.933 | 6.061 | 0.760 |
| Holt-Winters | 13.994 | 17.006 | 3.376 | 0.861 | 6.980 | 27.138 | 33.372 | 5.114 | 0.824 |
| Seasonal Naive | 32.015 | 35.098 | 7.899 | 0.435 | 11.103 | 44.124 | 57.462 | 7.978 | 0.478 |

* **Best model by cross-validation:** Random Forest
* **Hold-out test RMSE:** 36.11  (MAPE 5.70%), which is
  **37.2% lower RMSE than the Seasonal Naive baseline**.
* **Best model on the hold-out block:** Holt-Winters. Rankings can differ between CV and the hold-out
  because the hold-out is only 12 points; CV averages 5 separate forecast windows and is the
  more reliable basis for model selection.

![comparison](outputs/figures/05_model_comparison.png)
![test](outputs/figures/06_test_predictions.png)
![residuals](outputs/figures/07_residual_diagnostics.png)
![importance](outputs/figures/08_feature_importance.png)

## 4. Forecast
The selected model (Random Forest) was refitted on all available history. Intervals are 80% empirical
intervals derived from the backtest errors.

| date | forecast | lower_80 | upper_80 |
|---|---|---|---|
| 2026-01-01 | 453.850 | 433.230 | 474.350 |
| 2026-02-01 | 456.510 | 435.770 | 477.130 |
| 2026-03-01 | 474.900 | 453.330 | 496.360 |
| 2026-04-01 | 490.420 | 468.140 | 512.570 |
| 2026-05-01 | 536.610 | 512.230 | 560.850 |
| 2026-06-01 | 604.190 | 576.750 | 631.490 |
| 2026-07-01 | 653.690 | 623.990 | 683.220 |
| 2026-08-01 | 646.980 | 617.590 | 676.210 |
| 2026-09-01 | 578.050 | 551.790 | 604.160 |
| 2026-10-01 | 507.660 | 484.600 | 530.600 |
| 2026-11-01 | 516.930 | 493.450 | 540.280 |
| 2026-12-01 | 581.040 | 554.640 | 607.290 |

Total forecast for the next 12 periods is **+5.9%** versus the last 12 observed periods.

![forecast](outputs/figures/09_future_forecast.png)

## 5. Limitations
* Forecasts assume past patterns (trend + seasonality) continue; they cannot anticipate shocks such as new competitors or pandemics.
* Accuracy degrades with horizon because recursive forecasts feed on their own predictions.
* Only the target's own history is used; adding drivers (price, promotions, holidays, macro data) is the natural next step.
* Intervals come from a limited number of backtest errors and are approximate.
