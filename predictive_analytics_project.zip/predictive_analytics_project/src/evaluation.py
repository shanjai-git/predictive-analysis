"""Accuracy metrics and honest, time-aware validation."""
import numpy as np
import pandas as pd


def regression_metrics(actual, pred) -> dict:
    a, p = np.asarray(actual, float), np.asarray(pred, float)
    err = a - p
    ss_res, ss_tot = np.sum(err ** 2), np.sum((a - a.mean()) ** 2)
    return {
        "MAE": float(np.mean(np.abs(err))),
        "RMSE": float(np.sqrt(np.mean(err ** 2))),
        "MAPE_%": float(np.mean(np.abs(err / a)) * 100),
        "R2": float(1 - ss_res / ss_tot) if ss_tot > 0 else float("nan"),
    }


def rolling_origin_cv(factories: dict, y: pd.Series, horizon: int, n_folds: int):
    """Expanding-window backtest ("walk-forward validation").

    Fold k trains on everything before a cut-off and forecasts the next
    ``horizon`` periods - exactly how the model is used in production.
    Random K-fold would leak the future into training, so it is NOT used.

    Returns (summary_df, predictions_df)
    """
    n = len(y)
    rows = []
    for name, make in factories.items():
        for k in range(n_folds, 0, -1):
            end = n - horizon * k
            train, test = y.iloc[:end], y.iloc[end:end + horizon]
            model = make().fit(train)
            pred = model.forecast(horizon)
            rows.append(pd.DataFrame({
                "model": name, "fold": n_folds - k + 1, "date": test.index,
                "step": np.arange(1, len(test) + 1), "actual": test.to_numpy(), "pred": pred}))
    preds = pd.concat(rows, ignore_index=True)

    per_fold = [
        {"model": name, "fold": fold, **regression_metrics(g["actual"], g["pred"])}
        for (name, fold), g in preds.groupby(["model", "fold"])
    ]
    per_fold = pd.DataFrame(per_fold)
    summary = (per_fold.groupby("model")[["MAE", "RMSE", "MAPE_%", "R2"]].mean()
               .add_prefix("CV_").sort_values("CV_RMSE"))
    summary["CV_RMSE_std"] = per_fold.groupby("model")["RMSE"].std()
    return summary, preds


def holdout_evaluation(factories: dict, train: pd.Series, test: pd.Series):
    """Fit every model on ``train`` and score on the untouched ``test`` block."""
    results, forecasts, fitted = [], {}, {}
    for name, make in factories.items():
        model = make().fit(train)
        pred = model.forecast(len(test))
        forecasts[name], fitted[name] = pred, model
        results.append({"model": name, **regression_metrics(test.to_numpy(), pred)})
    table = pd.DataFrame(results).set_index("model").add_prefix("Test_").sort_values("Test_RMSE")
    return table, forecasts, fitted


def interval_from_cv(cv_preds: pd.DataFrame, model: str, level: float = 0.8):
    """Empirical prediction-interval multipliers from backtest relative errors."""
    g = cv_preds[cv_preds["model"] == model]
    rel = (g["actual"] - g["pred"]) / g["pred"]
    lo, hi = (1 - level) / 2, 1 - (1 - level) / 2
    return float(rel.quantile(lo)), float(rel.quantile(hi))
