"""Project-wide configuration."""

# Default seasonal period for each supported pandas frequency alias.
SEASON_LENGTH = {"MS": 12, "QS": 4, "D": 7}

# Pandas period alias used to align timestamps to the start of a period.
PERIOD_ALIAS = {"MS": "M", "QS": "Q"}

RANDOM_STATE = 42
