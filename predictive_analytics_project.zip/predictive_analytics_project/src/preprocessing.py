"""Cleaning and preprocessing of a raw historical dataset."""
import numpy as np
import pandas as pd

from .config import PERIOD_ALIAS


def load_raw(path: str) -> pd.DataFrame:
    return pd.read_csv(path)


def decompose(y: pd.Series, m: int, log: bool = False):
    """Classical decomposition: centred moving-average trend + mean seasonal profile.

    Returns (trend, seasonal, residual) in the same space as the input
    (log space if ``log=True``).
    """
    v = np.log(y) if log else y.astype(float)
    trend = v.rolling(m, center=True, min_periods=max(m // 2, 1)).mean()
    if m % 2 == 0:  # 2 x m moving average for even periods
        trend = trend.rolling(2, center=True, min_periods=1).mean()
    pos = np.arange(len(v)) % m
    seasonal = (v - trend).groupby(pos).transform("mean")
    seasonal = seasonal - seasonal.mean()
    resid = v - trend - seasonal
    return trend, seasonal, resid


def detect_outliers(y: pd.Series, m: int, threshold: float = 4.0) -> pd.Series:
    """Flag *isolated* outliers using a robust z-score of the decomposition residual.

    Runs of 2+ consecutive flagged points are treated as a genuine level shift
    (real behaviour, not an error) and are NOT flagged.
    """
    use_log = bool((y > 0).all())
    _, _, resid = decompose(y, m, log=use_log)
    med = resid.median()
    mad = (resid - med).abs().median() * 1.4826
    z = (resid - med) / (mad if mad > 0 else resid.std())
    flagged = z.abs() > threshold
    isolated = flagged & ~flagged.shift(1, fill_value=False) & ~flagged.shift(-1, fill_value=False)
    return isolated


def clean_series(df: pd.DataFrame, date_col: str, target_col: str, freq: str, m: int):
    """Turn a raw table into a clean, regular, gap-free time series.

    Returns
    -------
    clean : pd.Series        regular index, no NaN
    report : dict            what was fixed
    raw_aligned : pd.Series  regular index, before outlier removal / interpolation
    outlier_mask, missing_mask : boolean Series on the regular index
    """
    report = {"rows_raw": int(len(df))}
    d = df[[date_col, target_col]].copy()

    # 1. parse dates and numeric target --------------------------------------
    d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
    report["unparseable_dates_dropped"] = int(d[date_col].isna().sum())
    d = d.dropna(subset=[date_col])

    was_null = d[target_col].isna()
    numeric = pd.to_numeric(d[target_col], errors="coerce")
    report["non_numeric_values_coerced"] = int((numeric.isna() & ~was_null).sum())
    d[target_col] = numeric

    # 2. align to period start, remove duplicates, sort ----------------------
    if freq in PERIOD_ALIAS:
        d[date_col] = d[date_col].dt.to_period(PERIOD_ALIAS[freq]).dt.to_timestamp()
    else:
        d[date_col] = d[date_col].dt.normalize()
    before = len(d)
    d = d.drop_duplicates(subset=[date_col], keep="first")
    report["duplicate_rows_removed"] = int(before - len(d))
    d = d.sort_values(date_col)

    # 3. regular index: expose missing periods as NaN ------------------------
    full_index = pd.date_range(d[date_col].min(), d[date_col].max(), freq=freq)
    raw_aligned = d.set_index(date_col)[target_col].reindex(full_index)
    raw_aligned.index.name = "date"
    raw_aligned.name = target_col
    report["missing_periods_inserted"] = int(len(full_index) - len(d))
    missing_mask = raw_aligned.isna()
    report["missing_values_total"] = int(missing_mask.sum())

    # 4. outliers: detect on a provisional fill, blank them, re-interpolate --
    provisional = raw_aligned.interpolate(method="time", limit_direction="both")
    outlier_mask = detect_outliers(provisional, m)
    report["outliers_replaced"] = int(outlier_mask.sum())
    report["outlier_dates"] = [str(x.date()) for x in outlier_mask[outlier_mask].index]

    cleaned = raw_aligned.mask(outlier_mask).interpolate(method="time", limit_direction="both")
    cleaned.index.freq = full_index.freq

    report["rows_clean"] = int(len(cleaned))
    report["date_range"] = f"{cleaned.index.min().date()} to {cleaned.index.max().date()}"
    assert cleaned.notna().all()
    return cleaned, report, raw_aligned, outlier_mask, missing_mask
