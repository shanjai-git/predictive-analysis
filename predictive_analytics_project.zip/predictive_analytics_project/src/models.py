"""Forecasting models behind one interface:  ``fit(y: pd.Series)`` / ``forecast(h)``.

* SeasonalNaive   - baseline: "same period last cycle"
* HoltWinters     - exponential smoothing (damped trend + seasonality), time-series model
* MLForecaster    - regression on lag/rolling/calendar features (Linear, Ridge,
                    Random Forest, Gradient Boosting) with recursive multi-step forecasting
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .config import RANDOM_STATE
from .features import default_lags, default_windows, make_features


class BaseForecaster:
    name = "base"

    def _remember_index(self, y: pd.Series):
        self._last = y.index[-1]
        self._freq = y.index.freq or pd.infer_freq(y.index)

    def future_index(self, h: int) -> pd.DatetimeIndex:
        return pd.date_range(self._last, periods=h + 1, freq=self._freq)[1:]

    # optional log transform so multiplicative seasonality becomes additive
    def _setup_transform(self, values, want_log):
        self._log = bool(want_log and np.all(values > 0))

    def _fwd(self, v):
        return np.log(v) if self._log else np.asarray(v, dtype=float)

    def _inv(self, v):
        return np.exp(v) if self._log else v


class SeasonalNaive(BaseForecaster):
    def __init__(self, m, name="Seasonal Naive"):
        self.m, self.name = m, name

    def fit(self, y):
        self._remember_index(y)
        self._tail = y.to_numpy(dtype=float)[-self.m:]
        return self

    def forecast(self, h):
        return np.resize(self._tail, h)


class HoltWinters(BaseForecaster):
    """Additive Holt-Winters (damped trend) fitted by minimising one-step SSE.
    Works on log(y), which makes it a multiplicative-seasonality model."""

    def __init__(self, m, damped=True, log=True, name="Holt-Winters"):
        self.m, self.damped, self.log, self.name = m, damped, log, name

    def _run(self, params, x):
        alpha, beta, gamma, phi = params
        m = self.m
        level = x[:m].mean()
        trend = (x[m:2 * m].mean() - x[:m].mean()) / m
        season = list(x[:m] - level)
        sse = 0.0
        for t in range(m, len(x)):
            s = season[t % m]
            pred = level + phi * trend + s
            err = x[t] - pred
            sse += err * err
            new_level = alpha * (x[t] - s) + (1 - alpha) * (level + phi * trend)
            trend = beta * (new_level - level) + (1 - beta) * phi * trend
            season[t % m] = gamma * (x[t] - level - phi * trend) + (1 - gamma) * s
            level = new_level
        return sse, level, trend, season

    def fit(self, y):
        self._remember_index(y)
        self._setup_transform(y.to_numpy(), self.log)
        x = self._fwd(y.to_numpy(dtype=float))
        if len(x) < 2 * self.m:
            raise ValueError("Holt-Winters needs at least two full seasons of data")
        phi_bounds = (0.8, 1.0) if self.damped else (1.0, 1.0)
        bounds = [(0.001, 0.999), (0.0001, 0.5), (0.001, 0.999), phi_bounds]
        best = None
        for x0 in ([0.3, 0.05, 0.2, 0.98], [0.6, 0.1, 0.1, 0.95], [0.1, 0.01, 0.5, 1.0]):
            x0[3] = min(max(x0[3], phi_bounds[0]), phi_bounds[1])
            res = minimize(lambda p: self._run(p, x)[0], x0, bounds=bounds, method="L-BFGS-B")
            if best is None or res.fun < best.fun:
                best = res
        self.params_ = best.x
        _, self._level, self._trend, self._season = self._run(best.x, x)
        self._n = len(x)
        return self

    def forecast(self, h):
        phi = self.params_[3]
        out = []
        for step in range(1, h + 1):
            damp = sum(phi ** i for i in range(1, step + 1))
            out.append(self._level + damp * self._trend + self._season[(self._n + step - 1) % self.m])
        return self._inv(np.array(out))


class MLForecaster(BaseForecaster):
    """Regression forecaster.

    1. log-transform (if y > 0) and remove a linear trend  -> stationary-ish target z
       (tree models cannot extrapolate a trend, so we model the detrended signal)
    2. learn z_t = f(lags, rolling stats, season position)
    3. forecast recursively: each prediction is fed back as the next lag
    4. add the trend back and invert the log
    """

    def __init__(self, estimator, m, name, log=True):
        self.estimator, self.m, self.name, self.log = estimator, m, name, log
        self.lags, self.windows = default_lags(m), default_windows(m)

    def fit(self, y):
        self._remember_index(y)
        self._setup_transform(y.to_numpy(), self.log)
        v = self._fwd(y.to_numpy(dtype=float))
        t = np.arange(len(v))
        self._coef = np.polyfit(t, v, 1)
        z = v - np.polyval(self._coef, t)
        X = make_features(pd.Series(z), self.m, self.lags, self.windows)
        ok = X.notna().all(axis=1).to_numpy()
        self.feature_names_ = list(X.columns)
        self.estimator.fit(X[ok], z[ok])
        self._z, self._n = z, len(z)
        return self

    def forecast(self, h):
        z = list(self._z)
        for _ in range(h):
            X = make_features(pd.Series(z + [np.nan]), self.m, self.lags, self.windows).iloc[[-1]]
            z.append(float(self.estimator.predict(X)[0]))
        zf = np.array(z[self._n:])
        v = zf + np.polyval(self._coef, np.arange(self._n, self._n + h))
        return self._inv(v)


def build_model_factories(m: int) -> dict:
    """name -> zero-argument callable returning a fresh, unfitted model."""
    rs = RANDOM_STATE
    return {
        "Seasonal Naive": lambda: SeasonalNaive(m),
        "Holt-Winters": lambda: HoltWinters(m),
        "Linear Regression": lambda: MLForecaster(
            make_pipeline(StandardScaler(), LinearRegression()), m, "Linear Regression"),
        "Ridge Regression": lambda: MLForecaster(
            make_pipeline(StandardScaler(), Ridge(alpha=1.0)), m, "Ridge Regression"),
        "Random Forest": lambda: MLForecaster(
            RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=rs, n_jobs=-1),
            m, "Random Forest"),
        "Gradient Boosting": lambda: MLForecaster(
            GradientBoostingRegressor(n_estimators=300, learning_rate=0.05, max_depth=3,
                                      subsample=0.8, random_state=rs),
            m, "Gradient Boosting"),
    }
