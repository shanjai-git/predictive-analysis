"""Synthetic 'messy' historical sales data.

No real dataset ships with the project, so this module creates a realistic
monthly sales history that deliberately contains the problems found in real
data: missing values, missing rows, duplicates, text in numeric columns,
isolated outliers and unsorted rows.  Swap in your own CSV with
``python run_pipeline.py --data your.csv --date-col ... --target-col ...``.
"""
import numpy as np
import pandas as pd


def generate_sales_data(start="2014-01-01", periods=144, seed=42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.date_range(start, periods=periods, freq="MS")
    t = np.arange(periods)
    month = dates.month.to_numpy()

    # Trend: steady growth that accelerates after ~2019 (structural change).
    trend = 200 + 1.6 * t + 0.012 * np.maximum(t - 60, 0) ** 2

    # Seasonality (multiplicative): annual wave + semi-annual wave + holiday bump.
    seasonal = (
        1
        + 0.16 * np.sin(2 * np.pi * (month - 4) / 12)
        + 0.06 * np.sin(4 * np.pi * month / 12)
        + np.where(month == 11, 0.12, 0)
        + np.where(month == 12, 0.22, 0)
    )
    noise = rng.lognormal(mean=0, sigma=0.035, size=periods)
    sales = trend * seasonal * noise

    df = pd.DataFrame({"date": dates, "monthly_sales": sales.round(2)})

    # ---- inject real-world data problems --------------------------------
    outlier_idx = rng.choice(np.arange(10, periods - 5), size=5, replace=False)
    for i, factor in zip(outlier_idx, [1.7, 0.45, 1.55, 0.5, 1.8]):
        df.loc[i, "monthly_sales"] = round(df.loc[i, "monthly_sales"] * factor, 2)

    missing_idx = rng.choice(np.arange(5, periods - 5), size=6, replace=False)
    df.loc[missing_idx, "monthly_sales"] = np.nan

    df["monthly_sales"] = df["monthly_sales"].astype(object)
    df.loc[int(rng.integers(20, 100)), "monthly_sales"] = "unknown"   # text in numeric column

    drop_rows = rng.choice(np.arange(8, periods - 8), size=3, replace=False)
    df = df.drop(index=drop_rows)                                   # missing periods
    df = pd.concat([df, df.sample(3, random_state=seed)])          # duplicates
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)  # unsorted
    df["date"] = df["date"].dt.strftime("%Y-%m-%d")
    return df


if __name__ == "__main__":
    out = "data/raw/sales_history.csv"
    generate_sales_data().to_csv(out, index=False)
    print(f"Saved {out}")
