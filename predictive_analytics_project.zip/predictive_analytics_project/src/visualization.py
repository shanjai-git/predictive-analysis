"""All figures.  Every function saves a PNG and closes the figure."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .preprocessing import decompose

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 140, "axes.grid": True, "grid.alpha": 0.3,
    "axes.spines.top": False, "axes.spines.right": False, "axes.titlesize": 12,
    "axes.titleweight": "bold", "font.size": 10,
})
BLUE, ORANGE, GREEN, RED, GREY = "#2563eb", "#f59e0b", "#16a34a", "#dc2626", "#6b7280"


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def plot_cleaning(raw, clean, outlier_mask, missing_mask, path, ylabel="value"):
    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.plot(clean.index, clean, color=BLUE, lw=1.6, label="Cleaned series")
    ax.scatter(raw.index[outlier_mask], raw[outlier_mask], color=RED, zorder=5, s=45,
               label=f"Outliers replaced ({int(outlier_mask.sum())})")
    ax.scatter(clean.index[missing_mask], clean[missing_mask], color=ORANGE, zorder=5, s=45,
               marker="D", label=f"Missing values interpolated ({int(missing_mask.sum())})")
    ax.set(title="Data cleaning: what was fixed", ylabel=ylabel)
    ax.legend()
    _save(fig, path)


def plot_decomposition(y, m, path):
    trend, seasonal, resid = decompose(y, m, log=False)
    fig, axes = plt.subplots(4, 1, figsize=(11, 8), sharex=True)
    for ax, (s, title, c) in zip(axes, [(y, "Observed", BLUE), (trend, "Trend", GREEN),
                                       (seasonal, "Seasonal component", ORANGE), (resid, "Residual", GREY)]):
        ax.plot(s.index, s, color=c, lw=1.4)
        ax.set_ylabel(title)
    axes[0].set_title("Classical decomposition (trend + seasonality + residual)")
    _save(fig, path)


def plot_seasonality(y, m, path):
    pos = y.index.month if m == 12 else (np.arange(len(y)) % m) + 1
    labels = (["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
              if m == 12 else [str(i) for i in range(1, m + 1)])
    # remove the trend so months are comparable across years
    trend, _, _ = decompose(y, m, log=False)
    ratio = (y / trend).to_numpy()
    groups = [ratio[np.asarray(pos) == k] for k in range(1, m + 1)]
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.boxplot(groups, tick_labels=labels, patch_artist=True,
               boxprops=dict(facecolor="#bfdbfe"), medianprops=dict(color=RED))
    ax.axhline(1, color=GREY, ls="--")
    ax.set(title="Seasonal pattern (value / trend)", ylabel="ratio to trend")
    _save(fig, path)


def plot_acf(y, m, path, max_lag=None):
    x = np.diff(np.log(y) if (y > 0).all() else y.to_numpy())
    x = x - x.mean()
    max_lag = max_lag or 2 * m
    acf = [np.sum(x[k:] * x[:len(x) - k]) / np.sum(x * x) for k in range(max_lag + 1)]
    fig, ax = plt.subplots(figsize=(10, 3.8))
    ax.bar(range(max_lag + 1), acf, color=BLUE, width=0.4)
    ci = 1.96 / np.sqrt(len(x))
    ax.axhspan(-ci, ci, color=GREY, alpha=0.2, label="95% noise band")
    ax.set(title="Autocorrelation of period-on-period changes", xlabel="lag", ylabel="ACF")
    ax.legend()
    _save(fig, path)


def plot_model_comparison(cv_table, test_table, path):
    df = cv_table[["CV_RMSE"]].join(test_table[["Test_RMSE"]]).sort_values("CV_RMSE")
    x, w = np.arange(len(df)), 0.38
    fig, ax = plt.subplots(figsize=(10, 4.8))
    ax.bar(x - w / 2, df["CV_RMSE"], w, label="Cross-validation RMSE", color=BLUE)
    ax.bar(x + w / 2, df["Test_RMSE"], w, label="Hold-out test RMSE", color=ORANGE)
    ax.set_xticks(x, df.index, rotation=20, ha="right")
    ax.set(title="Model comparison (lower is better)", ylabel="RMSE")
    ax.legend()
    _save(fig, path)


def plot_test_predictions(train, test, forecasts, best, path, ylabel="value"):
    fig, ax = plt.subplots(figsize=(11, 5))
    hist = train.iloc[-36:]
    ax.plot(hist.index, hist, color=GREY, lw=1.4, label="Training history")
    ax.plot(test.index, test, color="black", lw=2.4, marker="o", ms=4, label="Actual")
    for name, p in forecasts.items():
        is_best = name == best
        ax.plot(test.index, p, lw=2.4 if is_best else 1.1, ls="-" if is_best else "--",
                color=GREEN if is_best else None, alpha=1 if is_best else 0.75,
                label=f"{name}" + (" (best)" if is_best else ""))
    ax.axvline(test.index[0], color=GREY, ls=":")
    ax.set(title="Hold-out test: predictions vs actual", ylabel=ylabel)
    ax.legend(ncol=2, fontsize=8)
    _save(fig, path)


def plot_final_forecast(history, fc, model_name, path, ylabel="value"):
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(history.index, history, color=BLUE, lw=1.6, label="Historical (cleaned)")
    ax.plot(fc.index, fc["forecast"], color=GREEN, lw=2.4, marker="o", ms=4, label=f"Forecast ({model_name})")
    ax.fill_between(fc.index, fc["lower_80"], fc["upper_80"], color=GREEN, alpha=0.2, label="80% interval")
    ax.axvline(history.index[-1], color=GREY, ls=":")
    ax.set(title=f"Forecast for the next {len(fc)} periods", ylabel=ylabel)
    ax.legend()
    _save(fig, path)


def plot_residuals(cv_preds, model, path):
    g = cv_preds[cv_preds["model"] == model].sort_values("date")
    res = g["actual"] - g["pred"]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    axes[0].scatter(g["pred"], g["actual"], color=BLUE, s=18, alpha=0.7)
    lim = [min(g["pred"].min(), g["actual"].min()), max(g["pred"].max(), g["actual"].max())]
    axes[0].plot(lim, lim, color=RED, ls="--")
    axes[0].set(title="Actual vs predicted", xlabel="predicted", ylabel="actual")
    axes[1].bar(g["date"], res, width=20, color=np.where(res >= 0, GREEN, RED))
    axes[1].set(title="Residuals over time", ylabel="actual - predicted")
    axes[2].hist(res, bins=15, color=BLUE, alpha=0.8, edgecolor="white")
    axes[2].axvline(0, color=RED, ls="--")
    axes[2].set(title="Residual distribution", xlabel="residual")
    fig.suptitle(f"Backtest diagnostics - {model}", fontweight="bold")
    _save(fig, path)


def plot_feature_importance(names, importances, path, title="Random Forest feature importance"):
    order = np.argsort(importances)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(np.array(names)[order], np.array(importances)[order], color=BLUE)
    ax.set(title=title, xlabel="importance")
    _save(fig, path)
