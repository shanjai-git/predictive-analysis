"""Feature engineering for the supervised (regression) forecasters."""
import numpy as np
import pandas as pd


def default_lags(m: int):
    return sorted({1, 2, 3, max(m // 2, 1), m})


def default_windows(m: int):
    return sorted({3, max(m // 2, 2), m})


def make_features(z: pd.Series, m: int, lags, windows) -> pd.DataFrame:
    """Build lag / rolling / calendar features.  Only *past* values are used
    (everything is shifted), so there is no look-ahead leakage."""
    X = {}
    for lag in lags:
        X[f"lag_{lag}"] = z.shift(lag)
    past = z.shift(1)
    for w in windows:
        X[f"roll_mean_{w}"] = past.rolling(w).mean()
        X[f"roll_std_{w}"] = past.rolling(w).std()
    X["momentum"] = z.shift(1) - z.shift(2)
    pos = np.arange(len(z)) % m
    X["season_sin"] = np.sin(2 * np.pi * pos / m)
    X["season_cos"] = np.cos(2 * np.pi * pos / m)
    return pd.DataFrame(X, index=z.index)
