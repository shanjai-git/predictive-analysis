#!/usr/bin/env python
"""End-to-end predictive analytics pipeline.

    python run_pipeline.py                       # uses the bundled synthetic sales data
    python run_pipeline.py --data my.csv --date-col Date --target-col Revenue --freq MS

Steps: load -> clean -> explore -> backtest models -> hold-out test -> forecast the future.
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from src import visualization as viz
from src.config import SEASON_LENGTH
from src.data_generator import generate_sales_data
from src.evaluation import holdout_evaluation, interval_from_cv, rolling_origin_cv
from src.models import build_model_factories
from src.preprocessing import clean_series, load_raw


def md_table(df: pd.DataFrame, digits=3) -> str:
    df = df.reset_index()
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            df[c] = df[c].dt.strftime("%Y-%m-%d")
    head = "| " + " | ".join(map(str, df.columns)) + " |"
    sep = "|" + "|".join("---" for _ in df.columns) + "|"
    body = ["| " + " | ".join(f"{v:.{digits}f}" if isinstance(v, float) else str(v) for v in row) + " |"
            for row in df.itertuples(index=False)]
    return "\n".join([head, sep, *body])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default="data/raw/sales_history.csv")
    ap.add_argument("--date-col", default="date")
    ap.add_argument("--target-col", default="monthly_sales")
    ap.add_argument("--freq", default="MS", choices=list(SEASON_LENGTH), help="MS=monthly, QS=quarterly, D=daily")
    ap.add_argument("--season-length", type=int, default=None)
    ap.add_argument("--horizon", type=int, default=12, help="periods to forecast / hold out")
    ap.add_argument("--cv-folds", type=int, default=5)
    ap.add_argument("--output-dir", default="outputs")
    args = ap.parse_args()

    m = args.season_length or SEASON_LENGTH[args.freq]
    fig_dir = os.path.join(args.output_dir, "figures")
    os.makedirs(fig_dir, exist_ok=True)
    os.makedirs("data/processed", exist_ok=True)
    F = lambda name: os.path.join(fig_dir, name)
    label = args.target_col

    # ---- 1. load ------------------------------------------------------------
    if not os.path.exists(args.data):
        print(f"[1/6] {args.data} not found - generating synthetic data")
        os.makedirs(os.path.dirname(args.data) or ".", exist_ok=True)
        generate_sales_data().to_csv(args.data, index=False)
    raw = load_raw(args.data)
    print(f"[1/6] Loaded {len(raw)} raw rows from {args.data}")

    # ---- 2. clean -----------------------------------------------------------
    y, report, raw_aligned, outliers, missing = clean_series(raw, args.date_col, args.target_col, args.freq, m)
    y.to_csv("data/processed/clean_series.csv", header=True)
    with open(os.path.join(args.output_dir, "cleaning_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    print(f"[2/6] Cleaned: {report}")
    if len(y) < max(3 * m, args.horizon * (args.cv_folds + 2)):
        raise SystemExit("Not enough history for the requested horizon / folds / seasonality.")

    # ---- 3. explore ---------------------------------------------------------
    viz.plot_cleaning(raw_aligned, y, outliers, missing, F("01_data_cleaning.png"), label)
    viz.plot_decomposition(y, m, F("02_decomposition.png"))
    viz.plot_seasonality(y, m, F("03_seasonality.png"))
    viz.plot_acf(y, m, F("04_autocorrelation.png"))
    print("[3/6] Exploratory plots saved")

    # ---- 4. model selection by walk-forward CV on the training block -------
    h = args.horizon
    train, test = y.iloc[:-h], y.iloc[-h:]
    factories = build_model_factories(m)
    cv_table, cv_preds = rolling_origin_cv(factories, train, h, args.cv_folds)
    best = cv_table.index[0]
    print(f"[4/6] Walk-forward CV done. Best model by CV RMSE: {best}")
    print(cv_table.round(3).to_string())

    # ---- 5. untouched hold-out test ----------------------------------------
    test_table, test_fc, fitted = holdout_evaluation(factories, train, test)
    results = cv_table.join(test_table)
    results.to_csv(os.path.join(args.output_dir, "model_comparison.csv"))
    cv_preds.to_csv(os.path.join(args.output_dir, "cv_predictions.csv"), index=False)
    print("[5/6] Hold-out test results")
    print(test_table.round(3).to_string())

    viz.plot_model_comparison(cv_table, test_table, F("05_model_comparison.png"))
    viz.plot_test_predictions(train, test, test_fc, best, F("06_test_predictions.png"), label)
    viz.plot_residuals(cv_preds, best, F("07_residual_diagnostics.png"))
    rf = fitted["Random Forest"]
    viz.plot_feature_importance(rf.feature_names_, rf.estimator.feature_importances_, F("08_feature_importance.png"))

    # ---- 6. refit best model on ALL data and forecast the future -----------
    final = factories[best]().fit(y)
    point = final.forecast(h)
    lo_q, hi_q = interval_from_cv(cv_preds, best, 0.8)
    fc = pd.DataFrame({"forecast": point, "lower_80": point * (1 + lo_q), "upper_80": point * (1 + hi_q)},
                      index=final.future_index(h))
    fc.index.name = "date"
    fc.round(2).to_csv(os.path.join(args.output_dir, "forecast_next_periods.csv"))
    viz.plot_final_forecast(y, fc, best, F("09_future_forecast.png"), label)
    print(f"[6/6] Forecast saved ({fc.index[0].date()} -> {fc.index[-1].date()})")

    # ---- report -------------------------------------------------------------
    naive_rmse = test_table.loc["Seasonal Naive", "Test_RMSE"]
    best_row = results.loc[best]
    gain = (1 - best_row["Test_RMSE"] / naive_rmse) * 100
    last_year = y.iloc[-h:].sum()
    growth = (fc["forecast"].sum() / last_year - 1) * 100
    report_md = f"""# Predictive Analytics Report

**Target:** `{args.target_col}`  |  **Frequency:** {args.freq}  |  **Seasonal period:** {m}  |  **Forecast horizon:** {h}

## 1. Data cleaning
Period covered: **{report['date_range']}** ({report['rows_clean']} periods after cleaning, from {report['rows_raw']} raw rows).

| Issue | Count | Treatment |
|---|---|---|
| Unparseable dates | {report['unparseable_dates_dropped']} | dropped |
| Non-numeric values | {report['non_numeric_values_coerced']} | converted to missing |
| Duplicate periods | {report['duplicate_rows_removed']} | removed |
| Missing periods (rows absent) | {report['missing_periods_inserted']} | inserted as gaps |
| Missing values (total) | {report['missing_values_total']} | time interpolation |
| Isolated outliers | {report['outliers_replaced']} | replaced by interpolation ({', '.join(report['outlier_dates']) or 'none'}) |

![cleaning](outputs/figures/01_data_cleaning.png)

## 2. Trend analysis
The decomposition separates a long-term trend from a repeating seasonal cycle and noise.

![decomposition](outputs/figures/02_decomposition.png)
![seasonality](outputs/figures/03_seasonality.png)

## 3. Models and validation
Six models were compared with **walk-forward cross-validation** ({args.cv_folds} folds x {h}-period forecasts) on the
training data, then scored once on the final {h} periods that no model had seen.

{md_table(results.round(3))}

* **Best model by cross-validation:** {best}
* **Hold-out test RMSE:** {best_row['Test_RMSE']:.2f}  (MAPE {best_row['Test_MAPE_%']:.2f}%), which is
  **{gain:.1f}% lower RMSE than the Seasonal Naive baseline**.
* **Best model on the hold-out block:** {test_table.index[0]}. Rankings can differ between CV and the hold-out
  because the hold-out is only {h} points; CV averages {args.cv_folds} separate forecast windows and is the
  more reliable basis for model selection.

![comparison](outputs/figures/05_model_comparison.png)
![test](outputs/figures/06_test_predictions.png)
![residuals](outputs/figures/07_residual_diagnostics.png)
![importance](outputs/figures/08_feature_importance.png)

## 4. Forecast
The selected model ({best}) was refitted on all available history. Intervals are 80% empirical
intervals derived from the backtest errors.

{md_table(fc.round(2))}

Total forecast for the next {h} periods is **{growth:+.1f}%** versus the last {h} observed periods.

![forecast](outputs/figures/09_future_forecast.png)

## 5. Limitations
* Forecasts assume past patterns (trend + seasonality) continue; they cannot anticipate shocks such as new competitors or pandemics.
* Accuracy degrades with horizon because recursive forecasts feed on their own predictions.
* Only the target's own history is used; adding drivers (price, promotions, holidays, macro data) is the natural next step.
* Intervals come from a limited number of backtest errors and are approximate.
"""
    with open("REPORT.md", "w") as f:
        f.write(report_md)
    print("Done. See REPORT.md and the outputs/ folder.")


if __name__ == "__main__":
    main()
